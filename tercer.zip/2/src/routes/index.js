const express = require('express')
const app = express ()
const path = require('path')
const hbs = require ('hbs')
const Estudiante = require('./../models/estudiante')
const Director = require('./../models/director')
const Aspirante = require('./../models/aspirante')
const dirViews = path.join(__dirname, '../../template/views')
const dirPartials = path.join(__dirname, '../../template/partials')
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

require('./../helpers/helpers')

//hbs
app.set('view engine', 'hbs')
app.set('views', dirViews)
hbs.registerPartials(dirPartials)


app.get('/', (req, res ) => {
	res.render('index', {
		titulo: 'Inicio',
	})	
});

app.post('/', (req, res ) => {

	let estudiante = new Estudiante ({
		nombre : req.body.nombre,
		password : bcrypt.hashSync(req.body.password, 10),
		correo: req.body.correo,
		cedula:req.body.cedula,
		telefono:req.body.telefono
		
	})

	estudiante.save((err, resultado) => {
		if (err){
			return res.render ('indexpost', {
				mostrar : err
			})			
		}		
		res.render ('indexpost', {			
				mostrar : resultado.nombre
			})		
	})			
});

app.get('/registrarCurso', (req, res ) => {
	res.render('registrarCurso', {
		titulo: 'Registro de Curso',
	})	
});
//inicio registrar curso
app.post('/registrarCurso', (req, res ) => {

	let director = new Director ({
		
		curso : req.body.curso,
		id: req.body.id,
		duracion : 	req.body.duracion,
		valor: req.body.valor	
	})

	director.save((err, resultado) => {
		if (err){
			return res.render ('indexpost', {
				mostrar : err
			})			
		}		
		res.render ('indexpost', {			
				mostrar : resultado
			})		
	})			
});
//fin registrar curso



app.get('/verCurso', (req,res) => {

	Aspirante.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}

		res.render ('verCurso',{
			listado : respuesta
		})
	})
})
//inicio registrar Aspirante

app.get('/regisAspirante', (req,res) => {

	Director.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}

		res.render ('regisAspirante',{
			titulo:'Registro de aspirante',
			listado : respuesta
		})
	})
})

app.post('/regisAspirante', (req, res ) => {

	let aspirante = new Aspirante({
		nombre : req.body.nombre,
		telefono:req.body.telefono,
		cedula:req.body.cedula,
		curso:req.body.curso
		
	})

	aspirante.save((err, resultado) => {
		if (err){
			return res.render ('indexpost', {
				mostrar : err
			})			
		}		
		res.render ('indexpost', {			
				mostrar : resultado.nombre
			})		
	})			
});
//fin registrar aspirante

app.get('/vernotas', (req,res) => {

	Estudiante.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}

		res.render ('vernotas',{
			listado : respuesta
		})
	})
})

app.get('/verCursos', (req,res) => {

	Director.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}

		res.render ('verCursos',{
			listado : respuesta
		})
	})
})
app.get('/verAspirante', (req,res) => {

	Aspirante.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}

		res.render ('verAspirante',{
			listado : respuesta
		})
	})
})

//fin
app.get('/actualizar', (req, res) => {	

		Estudiante.findById(req.session.usuario, (err, usuario) =>{
			//Estudiante.findById(req.usuario, (err, usuario) =>{
			if (err){
				return console.log(err)
			}

			if (!usuario){
			return res.redirect('/')
		}
			res.render ('actualizar',{
				nombre : usuario.nombre,
				matematicas : usuario.matematicas,
				ingles : usuario.ingles,
				programacion : usuario.programacion
			})
		});
	})	

app.post('/actualizar', (req, res) => {
	
	Estudiante.findOneAndUpdate({nombre : req.body.nombre}, req.body, {new : true, runValidators: true, context: 'query' }, (err, resultados) => {
		if (err){
			return console.log(err)
		}

		res.render ('actualizar', {
			nombre : resultados.nombre,
			matematicas : resultados.matematicas,
			ingles : resultados.ingles,
			programacion : resultados.programacion
		})
	})	
})
//eliminar estudiante
app.post('/eliminar', (req, res) => {
	
	Estudiante.findOneAndDelete({nombre : req.body.nombre}, req.body, (err, resultado) => {
		if (err){
			return console.log(err)
		}

		if(!resultado){
			res.render ('eliminar', {
			nombre : "no encontrado"			
		})

		}

		res.render ('eliminar', {
			nombre : resultado.nombre			
		})
	})	
})

//eliminar curso
app.post('/eliminarC', (req, res) => {
	
	Director.findOneAndDelete({curso : req.body.curso}, req.body, (err, resultado) => {
		if (err){
			return console.log(err)
		}

		if(!resultado){
			res.render ('eliminarC', {
			curso : "no encontrado"			
		})

		}

		res.render ('eliminarC', {
			curso : resultado.curso			
		})
	})	
})


//ingresar usuario
app.post('/ingresar', (req, res) => {	
	Estudiante.findOne({nombre : req.body.usuario}, (err, resultados) => {
		if (err){
			return console.log(err)
		}
		if(!resultados){
			return res.render ('ingresar', {
			mensaje : "Usuario no encontrado"			
			})
		}
		if(!bcrypt.compareSync(req.body.password, resultados.password)){
			return res.render ('ingresar', {
			mensaje : "Contraseña no es correcta"			
			})
		}	
		
			//Para crear las variables de sesión
			req.session.usuario = resultados._id	
			req.session.nombre = resultados.nombre

			// let token = jwt.sign({
   //          	usuario: resultados
   //      	}, 'virtual-tdea', { expiresIn: '12h' });
			// console.log(token)

			// localStorage.setItem('token', token);
			
			res.render('ingresar', {
						mensaje : "Bienvenido " + resultados.nombre,
						nombre : resultados.nombre,
						sesion : true						
						 })
	})	
})///termina ingreso




app.get('/salir', (req, res) => {
	req.session.destroy((err) => {
  		if (err) return console.log(err) 	
	})	
	// localStorage.setItem('token', '');
	res.redirect('/')	
})

app.get('*',(req,res)=> {
	res.render('error', {
		titulo: "Error 404",		
	})
});

module.exports = app